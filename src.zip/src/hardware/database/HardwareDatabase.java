
package hardware.database;
public class HardwareDatabase {
    public static void main(String[] args) {
    }
    
}
