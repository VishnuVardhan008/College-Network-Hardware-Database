
package hardware.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class device extends javax.swing.JFrame {
    public device() {
        initComponents();
    }


    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 20)); // NOI18N
        jLabel1.setText("Device ID");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 161, -1));

        jLabel2.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 20)); // NOI18N
        jLabel2.setText("Device Type");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 161, -1));

        jLabel3.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 20)); // NOI18N
        jLabel3.setText("Status");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 161, -1));

        jLabel4.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 20)); // NOI18N
        jLabel4.setText("Department ID");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 161, -1));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(197, 92, 220, -1));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 220, -1));
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(197, 184, 220, -1));

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, 220, -1));

        jButton1.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton1.setText("Submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 352, -1, -1));

        jButton2.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton2.setText("Modify");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 352, -1, -1));

        jButton3.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(321, 352, -1, -1));

        jButton5.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(186, 401, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Device Id", "Device Type", "Status", "Department Id"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 90, 350, 350));

        jButton6.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton6.setText("Clear");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 450, -1, -1));

        jButton7.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton7.setText("Load");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 450, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hardware/database/Background.jpg"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 510));

        jMenu2.setText("Devices");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        try 
	  {
            if(jTable1.getRowCount()==0)
              {
             JOptionPane.showMessageDialog(this, "Please load the table", "Notice", JOptionPane.INFORMATION_MESSAGE);

              }
              
              else
              {
             // Load Oracle JDBC Driver
              int r = jTable1.getSelectedRow();
              
              if(r<0)
              {
                  JOptionPane.showMessageDialog(this, "Please select a row", "Notice", JOptionPane.INFORMATION_MESSAGE);
              }
              
              else
              {
             // Load Oracle JDBC Driver
                DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
 
                Statement statement = con.createStatement();
         
                String query="update devices set device_type ='"+jTextField2.getText()+"' where device_id= '"+jTextField1.getText()+"'";
                //String sqlqry="insert into customers values()"
                ResultSet rs = statement.executeQuery(query);
            
                 System .out.println("Updated ....");
                  JOptionPane.showMessageDialog(this,"Updated Successfully","Notice",JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
              }
              }
              

      } 
	  
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        try 
	  {
             // Load Oracle JDBC Driver
                DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
 
                Statement statement = con.createStatement();
            
                String query= "INSERT INTO DEVICES VALUES(" + jTextField1.getText() + ","+ "'" +jTextField2.getText() +"',"+ "'"+jTextField3.getText() +"',+"+"'"+ jTextField4.getText()+"'" +")";
                //String sqlqry="insert into customers values()"
                ResultSet rs = statement.executeQuery(query);
            
                 System .out.println("Inserted ....");
                  JOptionPane.showMessageDialog(new JFrame(),"INSERTED SUCCESSFULLY", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
                
              

      } 
      catch(Exception e)
	  {
		System.out.println(e);
                JOptionPane.showMessageDialog(new JFrame(),e, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
		//JOptionPane.showMessageDialog(new JFrame(),"Please fill out all fields", "Notice", JOptionPane.INFORMATION_MESSAGE);
	  }
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try 
	  {
            if(jTable1.getRowCount()==0)
              {
             JOptionPane.showMessageDialog(this, "Please load the table", "Notice", JOptionPane.INFORMATION_MESSAGE);

              }
              
              else
              {
             // Load Oracle JDBC Driver
              int r = jTable1.getSelectedRow();
              
              if(r<0)
              {
                  JOptionPane.showMessageDialog(this, "Please select a row", "Notice", JOptionPane.INFORMATION_MESSAGE);
              }
              
              else
              {
             // Load Oracle JDBC Driver
                DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
 
                Statement statement = con.createStatement();
         
                String query="DELETE from devices where device_id="+jTextField1.getText();
                //String sqlqry="insert into customers values()"
                ResultSet rs = statement.executeQuery(query);
            
                 System .out.println("Deleted ....");
                 JOptionPane.showMessageDialog(this,"Deleted Successfully","Notice",JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
              }
              }
              

      } 
      catch(Exception e)
	  {
		  System.out.println(e);
	  }
    }

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        this.hide();
        MAIN m =new MAIN();
        m.show();
        dispose();           
    }

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
       
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        int rowindex = jTable1.getSelectedRow();
        
       
        jTextField1.setText(model.getValueAt(rowindex,0).toString());
        jTextField4.setText(model.getValueAt(rowindex,1).toString());
        jTextField3.setText(model.getValueAt(rowindex,2).toString());
        jTextField2.setText(model.getValueAt(rowindex,3).toString());
    }
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        jTable1.setModel(new DefaultTableModel(null,new String[]{"device_id","device_type","status","dept_id",}));
    }

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        try{
           DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
                Statement statement = con.createStatement();
                String query = "SELECT * FROM DEVICES";
                ResultSet rs = statement.executeQuery(query);
                
                DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
                              
                model.setRowCount(0);
                
                while(rs.next()) 
                {                      
                       model.addRow(new Object[]{rs.getString("device_id"),rs.getString("device_type"), rs.getString("status"),rs.getString("dept_id")});
                }
               
                rs.close();
                statement.close();
                con.close();
                
              

      } 
	  
	  catch(Exception e)
	  {
		 JOptionPane.showMessageDialog(new JFrame(),e, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
	  }
    }

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed


    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(device.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(device.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(device.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(device.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
      

    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new device().setVisible(true);
            }
        });
    }


    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
 
}
