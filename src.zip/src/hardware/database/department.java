
package hardware.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class department extends javax.swing.JFrame {


    public department() {
        initComponents();
    }

    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jTextField3 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton6 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 20)); // NOI18N
        jLabel1.setText("Department ID");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 174, -1));

        jLabel2.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 20)); // NOI18N
        jLabel2.setText("Department Name");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 194, -1));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 100, 214, -1));

        jButton1.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton1.setText("Submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 310, -1, -1));

        jButton2.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton2.setText("Modify");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(177, 310, -1, -1));

        jButton3.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 310, -1, -1));

        jButton4.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton4.setText("Load");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 450, -1, -1));

        jButton5.setFont(new java.awt.Font("Microsoft New Tai Lue", 0, 18)); // NOI18N
        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(188, 371, -1, -1));
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 146, 214, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Department Id", "Department Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(483, 91, 299, 350));

        jButton6.setFont(new java.awt.Font("Nirmala UI", 0, 18)); // NOI18N
        jButton6.setText("Clear");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 450, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hardware/database/Background.jpg"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 510));

        jMenu2.setText("Department");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try 
	  {
             // Load Oracle JDBC Driver
                DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
 
                Statement statement = con.createStatement();

                String query= "INSERT INTO DEPT VALUES(" + "'"+jTextField2.getText() + "',"+"'"+ jTextField3.getText()+"'" +")";
                //String sqlqry="insert into customers values()"
                ResultSet rs = statement.executeQuery(query);
            
                 System .out.println("Inserted ....");
                rs.close();
                statement.close();
                con.close();
                 JOptionPane.showMessageDialog(new JFrame(),"INSERTED SUCCESSFULLY", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
              

      } 
      catch(Exception e)
	  {
		System.out.println(e);
                JOptionPane.showMessageDialog(new JFrame(),e, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
		//JOptionPane.showMessageDialog(new JFrame(),"Please fill out all fields", "Notice", JOptionPane.INFORMATION_MESSAGE);
	  }
        
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        try 
	  {
             if(jTable1.getRowCount()==0)
             {
                JOptionPane.showMessageDialog(this, "Please load the table", "Notice", JOptionPane.INFORMATION_MESSAGE);
               }
              else
              {
             // Load Oracle JDBC Driver
              int r = jTable1.getSelectedRow();
              
              if(r<0)
              {
                  JOptionPane.showMessageDialog(this, "Please select single Row For Update..", "Notice", JOptionPane.INFORMATION_MESSAGE);
              }
              
              else
              {
             // Load Oracle JDBC Driver
                DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
 
                Statement statement = con.createStatement();
                String query="update dept set Dept_name ='"+jTextField3.getText()+"' where dept_id= '"+jTextField2.getText()+"'";
                //String sqlqry="insert into customers values()"
                ResultSet rs = statement.executeQuery(query);
            
                 System .out.println("Updated ....");
                  JOptionPane.showMessageDialog(this,"Updated Successfully","Notice",JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
              }
              }
           } 
	  
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
    }

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try{
           DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
                Statement statement = con.createStatement();
                String query = "SELECT * FROM DEPT";
                ResultSet rs = statement.executeQuery(query);
                
                DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
                              
                model.setRowCount(0);
                
                while(rs.next()) 
                {                      
                    model.addRow(new Object[]{ rs.getString("dept_id"),rs.getString("dept_name")});
                }
               
                rs.close();
                statement.close();
                con.close();
                
              

      } 
	  
	  catch(Exception e)
	  {
		 JOptionPane.showMessageDialog(new JFrame(),e, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
	  }
    }

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        this.hide();
        MAIN m =new MAIN();
        m.show();
        dispose();          
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try 
	  {
            if(jTable1.getRowCount()==0)
              {
             JOptionPane.showMessageDialog(this, "Please load the table", "Notice", JOptionPane.INFORMATION_MESSAGE);

              }
              
              else
              {
             // Load Oracle JDBC Driver
              int r = jTable1.getSelectedRow();
              
              if(r<0)
              {
                  JOptionPane.showMessageDialog(this, "Please select a row", "Notice", JOptionPane.INFORMATION_MESSAGE);
              }
              
              else
              {  
             // Load Oracle JDBC Driver
                DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
                // Connect to Oracle Database
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "vishnu", "vasavi123");
 
                Statement statement = con.createStatement();
                String query="DELETE from DEPT where DEPT_id="+jTextField2.getText();
                //String sqlqry="insert into customers values()"
                ResultSet rs = statement.executeQuery(query);
            
                 System .out.println("Deleted ....");
                 JOptionPane.showMessageDialog(this,"Deleted Successfully","Notice",JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
              }
              }
              

      } 
      catch(Exception e)
	  {
		  System.out.println(e);
	  }
    }

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        int rowindex = jTable1.getSelectedRow();
        
      
        jTextField2.setText(model.getValueAt(rowindex,0).toString());
        jTextField3.setText(model.getValueAt(rowindex,1).toString());
    }

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        jTable1.setModel(new DefaultTableModel(null,new String[]{"dept_id","dept_name"}));
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(department.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(department.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(department.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(department.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new department().setVisible(true);
            }
        });
    }


    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;

}
